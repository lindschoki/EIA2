interface AssocStringString {
    [key: string]: string;
}

interface PlayerData {
    name: string;
    score: number;
}
