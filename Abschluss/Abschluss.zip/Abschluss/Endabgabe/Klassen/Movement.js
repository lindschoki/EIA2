var Endabgabe;
(function (Endabgabe) {
    class Movement extends Endabgabe.ObjectStructure {
        move() { }
        ;
        draw() { }
        ;
    }
    Endabgabe.Movement = Movement;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=Movement.js.map