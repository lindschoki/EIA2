var Endabgabe;
(function (Endabgabe) {
    class ObjectStructure {
        move() { }
        draw() { }
    }
    Endabgabe.ObjectStructure = ObjectStructure;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=ObjectStructure.js.map