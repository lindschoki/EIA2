namespace Endabgabe {

    export class ObjectStructure {

        x: number;
        y: number;
        dx: number;
        dy: number;
        color: string;

        move(): void {}

        draw(): void {}
    }
}