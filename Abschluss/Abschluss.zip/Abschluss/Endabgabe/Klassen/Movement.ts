namespace Endabgabe {

    export class Movement extends ObjectStructure {

        geschwindigkeit: number;

        move(): void { };
        draw(): void { };
    }
}